<form id="searchform" class="search-form" action="<?php echo site_url('/'); ?>" role="search">
  <input type="search" name="s" required>
  <button type="submit"></button>
</form>